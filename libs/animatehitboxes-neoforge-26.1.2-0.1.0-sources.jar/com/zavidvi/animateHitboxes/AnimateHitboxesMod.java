package com.zavidvi.animateHitboxes;

import com.zavidvi.animateHitboxes.internal.HitboxDataLoader;
import com.zavidvi.animateHitboxes.platform.Services;
import net.minecraft.server.packs.PackType;
import org.jetbrains.annotations.ApiStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ApiStatus.Internal

public class AnimateHitboxesMod {
    public static final String MOD_ID = "animatehitboxes";
    public static final String MOD_NAME = "Animate Hitboxes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    public static void init() {
        Services.RESOURCE_PACK_PROVIDER.register(PackType.SERVER_DATA, HitboxDataLoader.HITBOX_DATA);
    }
}