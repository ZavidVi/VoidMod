package com.zavidvi.animateHitboxes.network;

import com.zavidvi.animateHitboxes.AnimateHitboxesMod;
import com.zavidvi.animateHitboxes.internal.HitboxDataLoader;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.network.ConfigurationTask;
import net.neoforged.neoforge.network.configuration.ICustomConfigurationTask;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;

@ApiStatus.Internal
public record SyncHitboxDataTask() implements ICustomConfigurationTask {
    public static final ConfigurationTask.Type TYPE = new ConfigurationTask.Type(Identifier.fromNamespaceAndPath(AnimateHitboxesMod.MOD_ID, "sync_hitbox_data"));

    @Override
    public void run(Consumer<CustomPacketPayload> sender) {
        SyncHitboxDataPayload payload = new SyncHitboxDataPayload(HitboxDataLoader.HITBOX_DATA.getHitboxData());
        sender.accept(payload);
    }

    @Override
    public @NotNull Type type() {
        return TYPE;
    }
}
