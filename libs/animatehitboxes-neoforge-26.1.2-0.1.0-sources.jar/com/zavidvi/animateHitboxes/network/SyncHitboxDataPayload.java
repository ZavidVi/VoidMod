package com.zavidvi.animateHitboxes.network;

import com.zavidvi.animateHitboxes.AnimateHitboxesMod;
import com.zavidvi.animateHitboxes.api.HitboxData;
import com.zavidvi.animateHitboxes.internal.HitboxDataLoader;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Map;

@ApiStatus.Internal
public record SyncHitboxDataPayload(Map<Identifier, List<HitboxData>> hitboxes) implements CustomPacketPayload {
    private static final StreamCodec<FriendlyByteBuf, Map<Identifier, List<HitboxData>>> DATA = data();
    public static final CustomPacketPayload.Type<SyncHitboxDataPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(AnimateHitboxesMod.MOD_ID, "sync_hitbox_data"));

    public static final StreamCodec<FriendlyByteBuf, SyncHitboxDataPayload> STREAM_CODEC = net.minecraft.network.codec.StreamCodec.composite(
            DATA,
            SyncHitboxDataPayload::hitboxes,
            SyncHitboxDataPayload::new
    );

    @Override
    public @NotNull Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    static StreamCodec<FriendlyByteBuf, Map<Identifier, List<HitboxData>>> data() {
        return new StreamCodec<>() {
            public @NotNull Map<Identifier, List<HitboxData>> decode(FriendlyByteBuf buf) {
                return buf.readMap(FriendlyByteBuf::readIdentifier, HitboxDataLoader::readBuf);
            }

            public void encode(FriendlyByteBuf buf, Map<Identifier, List<HitboxData>> hitboxData) {
                HitboxDataLoader.writeBuf(buf, hitboxData);
            }
        };
    }
}
