package com.zavidvi.animateHitboxes.api;

import net.minecraft.world.phys.Vec3;

/**
 * This record stores the position and scale that is calculated by the currently running GeckoLib animation.
 * <p>
 * For this to work well, I would recommend adding an empty bone to the model and using its pivot point as the starting
 * position of the hitbox. This position will be the bottom center of the hitbox entity.
 * <p>
 * A Blockbench plugin to help with adding and saving hitboxes is available on the GitHub page
 *
 * <h2>What {@code localPos} actually is</h2>
 * GeckoLib samples it as {@code inverse(preRenderMatrixState) * bonePose}. The pre-render matrix state is captured at
 * the very top of {@code GeoRenderer#performRenderPass}, <i>before</i> {@code scaleModelForRender} and
 * {@code adjustRenderPose}. Everything those two do - the render scale and the
 * {@code Axis.YP.rotationDegrees(180 - bodyYaw)} of {@code GeoEntityRenderer#applyRotations} - therefore ends up
 * <i>inside</i> {@code localPos}.
 * <p>
 * That makes {@code localPos} a ready-to-use, world axis aligned offset from the mob's position: it already has the
 * body rotation and the entity scale baked in. Adding it to the mob's position lands exactly on the pivot of the bone
 * as it is drawn on screen. GeckoLib says as much itself - the {@code worldPos} it hands to a bone position listener
 * is literally {@code localPos + DataTickets.POSITION}.
 * <p>
 * <b>So do not rotate, scale or mirror it.</b> Every one of those "fixes" has been tried and every one of them made the
 * hitboxes worse, because they re-apply a transform that is already present.
 *
 * @param localPos the local position of the GeckoLib bone referenced by {@link HitboxData#ref()}, relative to the mob's
 *                 position and already rotated/scaled into world space
 * @param modelPos the same bone in raw model space, i.e. the exact Blockbench coordinates of its pivot in 1/16 block
 *                 units. Purely diagnostic - it is directly comparable to the numbers Blockbench shows for the bone,
 *                 which makes it the quickest way to tell a coordinate bug apart from an animation authoring problem
 * @param scaleW   the x scale of the bone
 * @param scaleH   the y scale of the bone
 */
public record AnimationOverride(Vec3 localPos, Vec3 modelPos, float scaleW, float scaleH) {
}
