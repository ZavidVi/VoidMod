package com.zavidvi.animateHitboxes.internal;

import com.geckolib.animation.state.BoneSnapshot;
import com.geckolib.cache.model.GeoBone;
import com.geckolib.constant.DataTickets;
import com.geckolib.constant.dataticket.DataTicket;
import com.geckolib.event.GeoRenderEvent;
import com.geckolib.renderer.base.GeoRenderState;
import com.geckolib.renderer.base.RenderPassInfo;
import com.zavidvi.animateHitboxes.api.AnimationOverride;
import com.zavidvi.animateHitboxes.api.AttackBoxData;
import com.zavidvi.animateHitboxes.api.EntityHitboxData;
import com.zavidvi.animateHitboxes.api.GeckoLibMultiPartEntity;
import com.zavidvi.animateHitboxes.api.HitboxData;
import com.zavidvi.animateHitboxes.api.MultiPart;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.ApiStatus;

/**
 * Loader independent GeckoLib hooks that feed the animated bone positions back into the hitbox data.
 * <p>
 * GeckoLib 5 renders from a {@code GeoRenderState} instead of the animatable itself and no longer walks the bones
 * through {@code renderRecursively}, so instead of mixing into the renderer the bones we care about get a
 * {@link RenderPassInfo.BonePositionListener} attached for the duration of a render pass. The listeners are called
 * while the bone is being rendered, which is the only moment a bone actually has a position.
 */
@ApiStatus.Internal
public final class GeckoLibRenderHandler {

    /**
     * Carries the animatable through to the render pass since {@link GeoRenderEvent.Entity.Pre} only sees the render state
     */
    @SuppressWarnings("rawtypes")
    private static final DataTicket<GeckoLibMultiPartEntity> MULTI_PART_ENTITY =
            DataTicket.create("animatehitboxes:multi_part_entity", GeckoLibMultiPartEntity.class);

    private GeckoLibRenderHandler() {
    }

    public static void onCompileRenderState(GeoRenderEvent.Entity.CompileRenderState<?, ?> event) {
        if (event.getAnimatable() instanceof GeckoLibMultiPartEntity<?> multiPartEntity && multiPartEntity.getEntityHitboxData() != null) {
            event.addData(MULTI_PART_ENTITY, multiPartEntity);
        }
    }

    public static void onPreRender(GeoRenderEvent.Entity.Pre<?, ?> event) {
        GeoRenderState renderState = event.getRenderState();
        if (!renderState.hasGeckolibData(MULTI_PART_ENTITY)) {
            return;
        }
        GeckoLibMultiPartEntity<?> multiPartEntity = renderState.getGeckolibData(MULTI_PART_ENTITY);
        if (multiPartEntity instanceof GeckoLibMultiPartMob multiPartMob) {
            //Only the first render pass of a game tick may move the hitboxes
            if (!multiPartMob.animateHitboxes$isNewRenderTick()) {
                return;
            }
            multiPartMob.animateHitboxes$updateRenderTick();
        }
        RenderPassInfo<?> renderPass = event.getRenderPassInfo();
        //Resolved once for the whole pass so that every bone logged below shares a single moment in the animation
        boolean logThisPass = BoneDebug.shouldLogThisPass();
        for (GeoBone bone : event.getModel().topLevelBones()) {
            addListeners(renderPass, multiPartEntity, bone, logThisPass);
        }
    }

    private static void addListeners(RenderPassInfo<?> renderPass, GeckoLibMultiPartEntity<?> multiPartEntity, GeoBone bone, boolean logThisPass) {
        addListener(renderPass, multiPartEntity, bone, logThisPass);
        for (GeoBone child : bone.children()) {
            addListeners(renderPass, multiPartEntity, child, logThisPass);
        }
    }

    private static void addListener(RenderPassInfo<?> renderPass, GeckoLibMultiPartEntity<?> multiPartEntity, GeoBone bone, boolean logThisPass) {
        EntityHitboxData<?> hitboxData = multiPartEntity.getEntityHitboxData();
        String boneName = bone.name();
        boolean debugBone = logThisPass && BoneDebug.tracks(boneName);
        MultiPart<?> part = hitboxData.getCustomPart(boneName);
        if (part != null) {
            //Tick hitboxes
            renderPass.addBonePositionListener(bone, (worldPos, modelPos, localPos) -> {
                if (debugBone) {
                    log(renderPass, boneName, worldPos, modelPos, localPos);
                }
                if (localPos == null) {
                    return;
                }
                BoneSnapshot snapshot = bone.frameSnapshot;
                float scaleW = snapshot != null ? snapshot.getScaleX() : 1;
                float scaleH = snapshot != null ? snapshot.getScaleY() : 1;
                part.setOverride(new AnimationOverride(localPos, modelPos, scaleW, scaleH));
                //TODO: Could also update the position of the part directly but that would make separating the library from geckolib more tedious
            });
        } else if (hitboxData.getAnchorData().isAnchor(boneName)) {
            renderPass.addBonePositionListener(bone, (worldPos, modelPos, localPos) -> {
                if (debugBone) {
                    log(renderPass, boneName, worldPos, modelPos, localPos);
                }
                if (localPos != null) {
                    hitboxData.getAnchorData().updatePosition(boneName, localPos);
                }
            });
        } else if (multiPartEntity.canSetAnchorPos(boneName)) {
            renderPass.addBonePositionListener(bone, (worldPos, modelPos, localPos) -> {
                if (debugBone) {
                    log(renderPass, boneName, worldPos, modelPos, localPos);
                }
                if (localPos != null) {
                    multiPartEntity.setAnchorPos(boneName, localPos);
                }
            });
        } else {
            AttackBoxData attackBoxData = hitboxData.getAttackBoxData();
            HitboxData attackBox = attackBoxData.getAttackBox(boneName);
            if (attackBox != null) {
                renderPass.addBonePositionListener(bone, (worldPos, modelPos, localPos) -> {
                    if (debugBone) {
                        log(renderPass, boneName, worldPos, modelPos, localPos);
                    }
                    if (worldPos != null && attackBoxData.isAttackBoxActive(attackBox)) {
                        attackBoxData.moveActiveAttackBox(attackBox, worldPos);
                    }
                });
            } else if (debugBone) {
                //Bones that drive nothing still get a listener while debugging, so that a parent bone such as the one
                //an animation actually spins can be compared against Blockbench alongside its hitbox children
                renderPass.addBonePositionListener(bone, (worldPos, modelPos, localPos) ->
                        log(renderPass, boneName, worldPos, modelPos, localPos));
            }
        }
    }

    private static void log(RenderPassInfo<?> renderPass, String boneName, Vec3 worldPos, Vec3 modelPos, Vec3 localPos) {
        BoneDebug.log(boneName, renderPass.getOrDefaultGeckolibData(DataTickets.POSITION, Vec3.ZERO), worldPos, modelPos, localPos);
    }
}
