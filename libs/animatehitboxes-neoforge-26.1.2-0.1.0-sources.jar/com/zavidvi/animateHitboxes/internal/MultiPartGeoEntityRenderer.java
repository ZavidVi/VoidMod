package com.zavidvi.animateHitboxes.internal;

import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.ApiStatus;

/**
 * Mixin interface injected into GeoEntityRenderer.
 */
@ApiStatus.NonExtendable
@ApiStatus.Internal
public interface MultiPartGeoEntityRenderer {

    @ApiStatus.Internal
    void animateHitboxes$removeTickForEntity(Entity entity);
}
