package com.zavidvi.animateHitboxes.internal;

import com.zavidvi.animateHitboxes.AnimateHitboxesMod;
import com.zavidvi.animateHitboxes.api.HitboxData;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.gson.*;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.FileToIdConverter;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@ApiStatus.Internal
public class HitboxDataLoader extends SimplePreparableReloadListener<Map<Identifier, List<HitboxData>>> {
    private static final FileToIdConverter CONVERTER = FileToIdConverter.json("hitboxes");
    public static final HitboxDataLoader HITBOX_DATA = new HitboxDataLoader();
    private ImmutableMap<Identifier, List<HitboxData>> hitboxData = ImmutableMap.of();

    /**
     * Returns a list of the hitbox data that was loaded from data/hitboxes
     *
     * @param entityLocation the {@link EntityType#getKey} for the mob
     * @return a list of the mobs hitbox data
     */
    public List<HitboxData> getHitboxes(Identifier entityLocation) {
        return hitboxData.get(entityLocation);
    }

    public Map<Identifier, List<HitboxData>> getHitboxData() {
        return hitboxData;
    }

    @Override
    protected Map<Identifier, List<HitboxData>> prepare(@NotNull ResourceManager resourceManager, @NotNull ProfilerFiller profiler) {
        ImmutableMap.Builder<Identifier, List<HitboxData>> builder = ImmutableMap.builder();
        for (Map.Entry<Identifier, Resource> fileEntry : CONVERTER.listMatchingResources(resourceManager).entrySet()) {
            Identifier id = CONVERTER.fileToId(fileEntry.getKey());
            JsonElement json;
            try (BufferedReader reader = fileEntry.getValue().openAsReader()) {
                json = JsonParser.parseReader(reader);
            } catch (IOException | JsonParseException e) {
                AnimateHitboxesMod.LOGGER.error("Couldn't parse hitbox data file {}", fileEntry.getKey(), e);
                continue;
            }
            if (!(json instanceof JsonObject root)) {
                continue;
            }
            JsonArray elements = GsonHelper.getAsJsonArray(root, "elements");
            ImmutableList.Builder<HitboxData> listBuilder = ImmutableList.builder();
            for (JsonElement element : elements) {
                JsonObject elemObject = element.getAsJsonObject();
                double[] pos = new double[3];
                JsonArray posArray = GsonHelper.getAsJsonArray(elemObject, "pos");
                JsonElement refElement = elemObject.get("ref");
                String ref = refElement == null ? "" : refElement.getAsString();
                for (int i = 0; i < pos.length; ++i) {
                    pos[i] = GsonHelper.convertToDouble(posArray.get(i), "pos[" + i + "]");
                }
                if (elemObject.has("is_anchor") && GsonHelper.getAsBoolean(elemObject, "is_anchor")) {
                    listBuilder.add(new HitboxData(elemObject.get("name").getAsString(), new Vec3(pos[0] / 16, pos[1] / 16, pos[2] / 16), 0, 0, ref, false, true));
                } else {
                    float width = GsonHelper.getAsFloat(elemObject, "width") / 16;
                    float height = GsonHelper.getAsFloat(elemObject, "height") / 16;

                    JsonElement attackElement = elemObject.get("is_attack_box");
                    boolean isAttack = attackElement != null && attackElement.getAsBoolean();
                    listBuilder.add(new HitboxData(elemObject.get("name").getAsString(), new Vec3(pos[0] / 16, pos[1] / 16, pos[2] / 16), width, height, ref, isAttack, false));
                }
            }
            builder.put(id, listBuilder.build());
        }
        return builder.build();
    }

    @Override
    protected void apply(Map<Identifier, List<HitboxData>> object, @NotNull ResourceManager resourceManager, @NotNull ProfilerFiller profiler) {
        hitboxData = ImmutableMap.copyOf(object);
    }

    /**
     * Replaces all hitbox data with a copy of the given map
     *
     * @param dataMap the new hitbox data
     */
    public void replaceData(Map<Identifier, List<HitboxData>> dataMap) {
        AnimateHitboxesMod.LOGGER.info("Replacing client hitbox data for {} entities", dataMap.size());
        hitboxData = ImmutableMap.copyOf(dataMap);
    }

    public static List<HitboxData> readBuf(FriendlyByteBuf buf) {
        return buf.readList(HitboxData::readBuf);
    }

    public static void writeBuf(FriendlyByteBuf buf, List<HitboxData> hitboxes) {
        buf.writeCollection(hitboxes, HitboxData::writeBuf);
    }

    public static void writeBuf(FriendlyByteBuf buf, Map<Identifier, List<HitboxData>> hitboxData) {
        buf.writeMap(hitboxData, (buffer, key) -> buf.writeIdentifier(key), HitboxDataLoader::writeBuf);
    }
}
