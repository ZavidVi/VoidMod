package com.zavidvi.animateHitboxes.internal;

import com.geckolib.event.entity.CompileEntityRenderStateEvent;
import com.geckolib.event.entity.GeoEntityPreRenderEvent;
import net.neoforged.neoforge.common.NeoForge;

@SuppressWarnings("rawtypes")
public class GeckoLibEvents {

    public static void init() {
        NeoForge.EVENT_BUS.addListener(CompileEntityRenderStateEvent.class, GeckoLibEvents::compileRenderState);
        NeoForge.EVENT_BUS.addListener(GeoEntityPreRenderEvent.class, GeckoLibEvents::preRender);
    }

    private static void compileRenderState(CompileEntityRenderStateEvent event) {
        GeckoLibRenderHandler.onCompileRenderState(event);
    }

    private static void preRender(GeoEntityPreRenderEvent event) {
        GeckoLibRenderHandler.onPreRender(event);
    }
}
