package com.zavidvi.animateHitboxes.internal;

import com.zavidvi.animateHitboxes.AnimateHitboxesMod;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;
import java.util.Set;

/**
 * Opt-in logging of the positions GeckoLib reports for individual bones.
 * <p>
 * Enable it by adding a system property to the game's JVM arguments:
 * <pre>-Danimatehitboxes.debugBones=chreviaky,everyone1_hitbox</pre>
 * or {@code -Danimatehitboxes.debugBones=*} for every bone of every multipart mob. The log interval defaults to two
 * seconds and can be changed with {@code -Danimatehitboxes.debugInterval=<millis>}.
 * <p>
 * The value worth reading is {@code modelPos}. GeckoLib hands it over already converted back into raw model space -
 * the exact Blockbench coordinates of the bone's pivot, in 1/16 block units, with no body rotation, no entity scale
 * and no world position mixed in. Pausing the animation in Blockbench at the same timestamp and comparing the bone's
 * position there against a logged {@code modelPos} answers the only question that matters when a hitbox trajectory
 * looks wrong:
 * <ul>
 *     <li>they match - GeckoLib is animating exactly what Blockbench previews, so anything still off is in this mod's
 *     positioning code</li>
 *     <li>they differ - the animation itself resolves differently in game, and the problem is in how it was authored
 *     (global vs local rotation space, keyframes outside +-360 degrees, a bone whose parent carries a bind pose
 *     rotation, or a group that is excluded from the model export)</li>
 * </ul>
 * No previous fix attempt was ever checked against that, which is why three of them in a row looked well reasoned and
 * were still wrong.
 */
@ApiStatus.Internal
public final class BoneDebug {

    private static final String BONES_PROPERTY = "animatehitboxes.debugBones";
    private static final String INTERVAL_PROPERTY = "animatehitboxes.debugInterval";
    private static final Set<String> BONES = parseBones();
    private static final boolean ALL = BONES.contains("*");
    private static final long INTERVAL_MS = parseInterval();

    private static long nextLogTime;

    private BoneDebug() {
    }

    private static Set<String> parseBones() {
        String value = System.getProperty(BONES_PROPERTY, "");
        Set<String> bones = new ObjectOpenHashSet<>();
        for (String name : value.split(",")) {
            String trimmed = name.trim();
            if (!trimmed.isEmpty()) {
                bones.add(trimmed);
            }
        }
        if (!bones.isEmpty()) {
            AnimateHitboxesMod.LOGGER.info("Bone position debugging is enabled for {}", bones);
        }
        return bones;
    }

    private static long parseInterval() {
        try {
            return Math.max(50, Long.parseLong(System.getProperty(INTERVAL_PROPERTY, "2000")));
        } catch (NumberFormatException e) {
            return 2000;
        }
    }

    /**
     * @return {@code true} if any bone is being tracked at all. Checked before doing any per-bone work so that a normal
     * game pays nothing more than a static boolean read
     */
    public static boolean isEnabled() {
        return !BONES.isEmpty();
    }

    public static boolean tracks(String boneName) {
        return ALL || BONES.contains(boneName);
    }

    /**
     * Called once per mob per render pass so that every bone logged in the same pass shares one timestamp, which is
     * what makes the numbers comparable to each other
     *
     * @return {@code true} if this render pass should be logged
     */
    public static boolean shouldLogThisPass() {
        if (!isEnabled()) {
            return false;
        }
        long now = System.currentTimeMillis();
        if (now < nextLogTime) {
            return false;
        }
        nextLogTime = now + INTERVAL_MS;
        return true;
    }

    public static void log(String boneName, Vec3 entityPos, @Nullable Vec3 worldPos, @Nullable Vec3 modelPos, @Nullable Vec3 localPos) {
        AnimateHitboxesMod.LOGGER.info("[BoneDebug] {} entity={} modelPos(blockbench units)={} localPos(offset)={} worldPos={}",
                boneName, format(entityPos), format(modelPos), format(localPos), format(worldPos));
    }

    private static String format(@Nullable Vec3 vec) {
        return vec == null ? "null" : String.format(Locale.ROOT, "[%.3f, %.3f, %.3f]", vec.x, vec.y, vec.z);
    }
}
