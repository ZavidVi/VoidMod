package com.zavidvi.animateHitboxes;

import com.zavidvi.animateHitboxes.internal.GeckoLibEvents;
import com.zavidvi.animateHitboxes.network.NetworkRegistry;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
@Mod(AnimateHitboxesMod.MOD_ID)
public class NeoForgeAnimateHitboxesMod {

    public NeoForgeAnimateHitboxesMod(IEventBus modEventBus) {
        AnimateHitboxesMod.init();
        if (ModList.get().isLoaded("geckolib") && FMLEnvironment.getDist() == Dist.CLIENT) {
            GeckoLibEvents.init();
        }
        modEventBus.addListener(NetworkRegistry::init);
    }
}