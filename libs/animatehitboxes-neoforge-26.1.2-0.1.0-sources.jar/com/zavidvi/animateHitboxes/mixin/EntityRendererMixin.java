package com.zavidvi.animateHitboxes.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.zavidvi.animateHitboxes.api.MultiPartEntity;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Since 26.1 the culling box is no longer stored on the entity itself but supplied by its renderer,
 * so the multipart culling bounds have to be injected here instead of into {@code Entity}.
 */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {

    @ModifyReturnValue(method = "getBoundingBoxForCulling", at = @At("RETURN"))
    public AABB changeCullBox(AABB original, Entity entity) {
        if (entity instanceof MultiPartEntity<?> multiPartEntity && multiPartEntity.getEntityHitboxData() != null && multiPartEntity.getEntityHitboxData().hasCustomParts()) {
            return multiPartEntity.getEntityHitboxData().getCullingBounds();
        }
        return original;
    }
}
