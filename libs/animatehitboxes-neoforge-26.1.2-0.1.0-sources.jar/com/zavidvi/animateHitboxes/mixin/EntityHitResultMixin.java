package com.zavidvi.animateHitboxes.mixin;

import com.zavidvi.animateHitboxes.api.MultiPart;
import com.zavidvi.animateHitboxes.internal.MultiPartEntityHitResult;
import net.minecraft.world.phys.EntityHitResult;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Adds a {@link MultiPart} field that is used to determine the exact part hit during an attack
 */
@Mixin(EntityHitResult.class)
public abstract class EntityHitResultMixin implements MultiPartEntityHitResult {
    @Unique
    @Nullable
    private MultiPart<?> animateHitboxes$part;

    @Override
    public void animateHitboxes$setMultiPart(MultiPart<?> part) {
        this.animateHitboxes$part = part;
    }

    @Override
    public @Nullable MultiPart<?> animateHitboxes$getMultiPart() {
        return animateHitboxes$part;
    }
}
