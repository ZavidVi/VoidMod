package com.zavidvi.animateHitboxes.mixin;

import com.zavidvi.animateHitboxes.api.EntityHitboxData;
import com.zavidvi.animateHitboxes.api.HitboxData;
import com.zavidvi.animateHitboxes.api.MultiPart;
import com.zavidvi.animateHitboxes.api.MultiPartEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.debug.EntityHitboxDebugRenderer;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

/**
 * Used for debugging multiple hitboxes. Since 26.1 the debug hitboxes are emitted as gizmos from
 * {@link EntityHitboxDebugRenderer} instead of being drawn by the entity render dispatcher.
 */
@Mixin(EntityHitboxDebugRenderer.class)
public abstract class EntityHitboxDebugRendererMixin {

    @Unique
    private static final int animateHitboxes$CULLING_BOX_COLOR = 0xFFFF00FF;

    @Unique
    private static final int animateHitboxes$BOX_COLOR = 0xFF0000FF;

    @Unique
    private static final int animateHitboxes$HIT_COLOR = 0xFFFF0000;

    @Unique
    private static final int animateHitboxes$PART_COLOR = 0xFF00FF00;

    @Inject(method = "showHitboxes", at = @At("RETURN"))
    private void showMultiPartHitboxes(Entity entity, float partialTicks, boolean isServerEntity, CallbackInfo ci) {
        if (!(entity instanceof Mob mob) || !(entity instanceof MultiPartEntity<?> multiPartEntity)) {
            return;
        }
        EntityHitboxData<?> hitboxData = multiPartEntity.getEntityHitboxData();
        if (hitboxData == null) {
            return;
        }
        Vec3 offset = entity.getPosition(partialTicks).subtract(entity.position());
        if (hitboxData.hasCustomParts()) {
            animateHitboxes$cuboid(hitboxData.getCullingBounds().move(offset), animateHitboxes$CULLING_BOX_COLOR);
        }
        animateHitboxes$cuboid(hitboxData.getAttackBounds().move(offset), animateHitboxes$BOX_COLOR);

        Player player = Minecraft.getInstance().player;
        for (Map.Entry<HitboxData, Vec3> entry : hitboxData.getAttackBoxData().getActiveBoxes().entrySet()) {
            HitboxData hitbox = entry.getKey();
            EntityDimensions size = EntityDimensions.scalable(hitbox.width(), hitbox.height()).scale(mob.getScale());
            AABB attackBox = size.makeBoundingBox(entry.getValue());
            boolean hitsPlayer = player != null && player.getBoundingBox().intersects(attackBox);
            animateHitboxes$cuboid(attackBox, hitsPlayer ? animateHitboxes$HIT_COLOR : animateHitboxes$BOX_COLOR);
        }

        for (MultiPart<?> multiPart : hitboxData.getCustomParts()) {
            Entity part = multiPart.getEntity();
            Vec3 partOffset = part.getPosition(partialTicks).subtract(part.position());
            animateHitboxes$cuboid(part.getBoundingBox().move(partOffset), animateHitboxes$PART_COLOR);
        }
    }

    /**
     * Boxes that were never calculated sit at the world origin, so skip them instead of drawing a dot at 0/0/0
     */
    @Unique
    private static void animateHitboxes$cuboid(AABB box, int color) {
        if (box.getSize() > 0) {
            Gizmos.cuboid(box, GizmoStyle.stroke(color));
        }
    }
}
