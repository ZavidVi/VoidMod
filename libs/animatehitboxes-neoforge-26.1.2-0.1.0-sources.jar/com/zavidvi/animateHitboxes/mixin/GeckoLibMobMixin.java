package com.zavidvi.animateHitboxes.mixin;

import com.zavidvi.animateHitboxes.internal.GeckoLibMultiPartMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(Mob.class)
public abstract class GeckoLibMobMixin extends LivingEntity implements GeckoLibMultiPartMob {
    @Unique
    private int animateHitboxes$renderTick;

    protected GeckoLibMobMixin(EntityType<? extends LivingEntity> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    public boolean animateHitboxes$isNewRenderTick() {
        return animateHitboxes$renderTick < tickCount;
    }

    @Override
    public void animateHitboxes$updateRenderTick() {
        animateHitboxes$renderTick = tickCount;
    }
}
